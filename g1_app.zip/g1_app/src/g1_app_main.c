#include "g1_hal.h"


int main(int argc, char *argv[])
{
	log_debug("start g1_app %s\n", "demo 0.1");

	hal_ttyS0_init();
#if 1
	//hal_ut_thread();
	//hal_ut_ttyS0_echo();
	//hal_ut_LED_screen();
#endif

	

	
	for(;;){

		hal_ut_LED_screen();
		sleep(1);
	}
	return 0;
}
