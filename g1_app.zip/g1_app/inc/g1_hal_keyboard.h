#ifndef __G1_HAL_KEYBOARD_H__
#define __G1_HAL_KEYBOARD_H__


#endif/*__G1_HAL_KEYBOARD_H__*/
