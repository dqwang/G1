#ifndef __G1_HAL_TYPE_H__
#define __G1_HAL_TYPE_H__

typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned long  u32;

typedef signed char  s8;
typedef signed short s16;
typedef signed long  s32;


#endif/*__G1_HAL_TYPE_H__*/
