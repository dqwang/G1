#ifndef __G1_HAL_LED_SCREEN_H__
#define __G1_HAL_LED_SCREEN_H__


#endif/*__G1_HAL_LED_SCREEN_H__*/
