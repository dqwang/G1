#ifndef __G1_HAL_UT_H__
#define __G1_HAL_UT_H__

void hal_ut_thread(void);

void hal_ut_ttyS0(void);

void hal_ut_LED_screen(void);

#endif/*__G1_HAL_UT_H__*/

